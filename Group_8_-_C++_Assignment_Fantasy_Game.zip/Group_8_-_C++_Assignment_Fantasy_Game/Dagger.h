//Dagger.h: interface for the Dagger class.
//
//////////////////////////////////////////
#include "Weapons.h"

#ifndef DAGGER_H_INCLUDED
#define DAGGER_H_INCLUDED

class Dagger : public Weapons
{
public:

    Dagger();

};


#endif // DAGGER_H_INCLUDED
