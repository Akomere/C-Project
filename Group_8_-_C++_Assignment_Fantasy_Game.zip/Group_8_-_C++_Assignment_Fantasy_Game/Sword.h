//Sword.h: interface for the Sword class.
//
////////////////////////////////////////////

#include "Weapons.h"
#include "Item.h"


#ifndef SWORD_H_INCLUDED
#define SWORD_H_INCLUDED

class Sword : public Weapons
{
public:
    
    Sword();
};

#endif // SWORD_H_INCLUDED
