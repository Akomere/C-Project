//LeatherArmour.h: interface for the Leather Armour class.
//
///////////////////////////////////////////////////////
#include <iostream>
#include "LightGear.h"


#ifndef LEATHERARMOUR_H_INCLUDED
#define LEATHERARMOUR_H_INCLUDED

class LeatherArmour : public LightGear
{
public:

    LeatherArmour();

private:

};

#endif // LEATHERARMOUR_H_INCLUDED
