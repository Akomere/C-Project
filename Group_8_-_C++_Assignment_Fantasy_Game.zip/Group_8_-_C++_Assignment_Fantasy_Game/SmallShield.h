// SmallShield.h: interface for the Small Shield class.
//
//////////////////////////////////////////

#include "LightGear.h"


#ifndef SMALLSHIELD_H_INCLUDED
#define SMALLSHIELD_H_INCLUDED

class SmallShield : public LightGear
{
public:

    SmallShield();
};


#endif // SMALLSHIELD_H_INCLUDED
