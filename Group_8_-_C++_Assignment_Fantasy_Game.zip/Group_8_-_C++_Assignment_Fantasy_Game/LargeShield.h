//LargeShield.h: interface for the Large Shield class.
//
////////////////////////////////////////////////////
#include "HeavyGear.h"

#ifndef LARGESHIELD_H_INCLUDED
#define LARGESHIELD_H_INCLUDED

class LargeShield : public HeavyGear
{
public:
    LargeShield();



};


#endif // LARGESHIELD_H_INCLUDED
