//PlateArmour.h: interface for the Plate Armour class.
//
//////////////////////////////////////////////////
#include "HeavyGear.h"

#ifndef PLATEARMOUR_H_INCLUDED
#define PLATEARMOUR_H_INCLUDED

class PlateArmour : public HeavyGear
{
public:
    PlateArmour();
};

#endif // PLATEARMOUR_H_INCLUDED
